rombus_sh <- function (x, y, r = 3) 
{
    return(abs(x) + abs(y) - r)
}
