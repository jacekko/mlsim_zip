linear_sh <- function (x, y) 
{
    return(y - x)
}
