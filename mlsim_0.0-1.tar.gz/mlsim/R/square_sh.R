square_sh <- function (x, y, r = 3) 
{
    return(max(abs(x), abs(y)) - r)
}
