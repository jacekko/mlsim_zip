wave_sh <- function (x, y) 
{
    return(y - 5 * sin(x))
}
