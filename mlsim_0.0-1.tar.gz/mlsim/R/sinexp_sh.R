sinex_sh <- function (x, y) 
{
    return(y - 2 * x * sin(exp(0.5 * x)))
}
