circle_sh <- function (x, y, r = 3) 
{
    return(x^2 + y^2 - r^2)
}
